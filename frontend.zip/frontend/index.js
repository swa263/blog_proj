const express = require("express");
const bodyParser = require("body-parser");
const app = express();
const mysql = require("mysql");
var cors = require('cors')

app.use(cors())
// parse application/json
app.use(bodyParser.json());

//Create Database Connection
const conn = mysql.createConnection({
	host: "localhost",
	user: "root",
	password: "",
	database: "blog",
});

// connect to database
conn.connect((err) => {
	if (err) throw err;
	console.log("MySQL connected");
});

//for username and password
//app.post("api/create",(req,res)=>{
//	let data = { username: req.body.username, password: req.body.password};
//	let sql = "INSERT INTO bloggers SET ?";
//	let query = conn.query(sql, data, (err, result) => {
	//	if (err) throw err;
	//	res.send(JSON.stringify({ status: 200, error: null, response: "New Record is Added successfully" }));
	//});

//});

// creat a new Record
app.post("/api/create", (req, res) => {
	let data = { username: req.body.username, title: req.body.title, description: req.body.description };
	let sql = "INSERT INTO users SET ?";
	let query = conn.query(sql, data, (err, result) => {
		if (err) throw err;
		res.send(JSON.stringify({ status: 200, error: null, response: "New Record is Added successfully" }));
	});
});
// show all records
app.get("/api/view", (req, res) => {
	let sql = "SELECT * FROM users";
	let query = conn.query(sql, (err, result) => {
		if (err) throw err;
		res.send(JSON.stringify({ status: 200, error: null, response: result }));
	});
});

// show a single record
app.get("/api/view/:id", (req, res) => {
	let sql = "SELECT * FROM users WHERE id=" + req.params.id;
	let query = conn.query(sql, (err, result) => {
		if (err) throw err;
		res.send(JSON.stringify({ status: 200, error: null, response: result }));
	});
});

// delete the record
app.delete("/api/delete/:id", (req, res) => {
	let sql = "DELETE FROM users WHERE id=" + req.params.id + "";
	let query = conn.query(sql, (err, result) => {
		if (err) throw err;
		res.send(JSON.stringify({ status: 200, error: null, response: "Record deleted successfully" }));
	});
});

// update the Record
app.put("/api/update/", (req, res) => {
	let sql = "UPDATE users SET username='" + req.body.username + "', title='" + req.body.title + "', description='" + req.body.description+"' WHERE id=" + req.body.id;
	let query = conn.query(sql, (err, result) => {
		if (err) throw err;
		res.send(JSON.stringify({ status: 200, error: null, response: "Record updated SuccessFully" }));
	});
});



app.listen(2000, () => {
	console.log("server started on port 2000...");
});
